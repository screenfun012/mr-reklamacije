# Handoff: MR Engines — Client Portal

## Overview
A client-facing portal where MR Engines' foreign customers (Italy, Netherlands, Germany, France, Spain) sign in and track the status of their engine remanufacturing **claims** (reklamacije). This is the client's first digital touchpoint with the company, so the experience must feel powerful, industrial, reliable and premium — dark, mechanical, precise. Even when a claim is *rejected*, the client should stay calm because everything reads as professional and transparent.

Four screens: **Login → Welcome (first entry) → Claims list → Claim detail (read-only)**. Fully multilingual (EN default, plus SR/ES/NL/DE/FR).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show the intended look, layout, copy and behavior. They are **not production code to copy directly**.

`MR Engines Portal.dc.html` is a "Design Component" file: an HTML template plus a JavaScript logic class, run by a small custom runtime (`support.js`). **Do not port the runtime or the `.dc.html` format.** Read it as a spec.

The task is to **recreate these designs in the target codebase's environment**. The intended stack (from the brief) is: **React, Tailwind CSS v4, shadcn/ui, Figtree font, dark theme, OKLCH colors, responsive**. If that project doesn't exist yet, scaffold it with those choices. Use the codebase's existing components/patterns where they exist; match the visuals below pixel-for-pixel.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, copy, animations and interactions are all specified. Recreate the UI pixel-perfectly using the codebase's libraries. Exact hex values are given below (convert to OKLCH per the brief when defining Tailwind theme tokens).

---

## Design Tokens

### Colors (from the MR Engines brandbook)
| Token | Hex | Use |
|---|---|---|
| `brand.red` | `#ED1C24` | Primary CTA, accents, active states, brand mark |
| `brand.red.hover` | `#F0414A` | Hover state for red buttons |
| `brand.red.deep` | `#C8141B` | Gradient partner for red |
| `bg.base` | `#141414` | Login / welcome background base |
| `bg.shell` | `#18191A` | App shell background (claims/detail) |
| `surface` | `#202123` | Cards, panels, inputs container |
| `surface.raised` | `#25272A` | Card hover background |
| `surface.form` | `#191A1C` | Login form panel |
| `border` | `rgba(255,255,255,0.07)` | Card/section borders |
| `border.strong` | `rgba(255,255,255,0.12)` | Inputs, dividers |
| `text.primary` | `#F5F5F5` | Headings, primary text |
| `text.secondary` | `#A3A4A8` | Body / muted |
| `text.tertiary` | `#6E7075` | Labels, placeholders, mono captions |
| `text.body` | `#C9CACC` | Report body copy |

### Status colors
| Status | Text/icon | Background tint | Border |
|---|---|---|---|
| Accepted (success) | `#3DD693` | `rgba(31,169,113,0.13)` | `rgba(31,169,113,0.32)` |
| In progress (warning) | `#F5A623` | `rgba(245,166,35,0.12)` | `rgba(245,166,35,0.32)` |
| Rejected (error) | `#F0625B` | `rgba(217,45,32,0.13)` | `rgba(217,45,32,0.36)` |

Base status hues from the brandbook: success `#1FA971`, warning `#F5A623`, error `#D92D20` (lighter variants above are used for text/icons on the dark bg).

### Typography
- **Primary:** `Figtree` (Google Fonts), weights 400/500/600/700/800. Used for all UI text.
- **Monospace:** `JetBrains Mono`, weights 400/500/700. Used for IDs, serial numbers, phone numbers, technical/eyebrow labels, percentages.
- Headline scale: hero `clamp(33px,4.2vw,54px)` weight 800, letter-spacing `-0.025em`; page H1 `33px` weight 700; detail engine title `clamp(30px,4vw,42px)`.
- Body `14.5px`, line-height `1.55`; report body `14.5px` line-height `1.68`.
- Eyebrow labels: `11px`, `letter-spacing:0.16em`, `text-transform:uppercase`, color `#A3A4A8` or `#ED1C24`.

### Spacing / radius / shadow
- Card padding `22px`–`26px`; section gaps `18px`–`24px`; page max-width `1180px`, padding `38px 28px 90px`.
- Border radius: buttons/inputs `4px`, cards `6px`, badges `3px`, avatars `50%`.
- Card shadow (elevated/login): `0 40px 100px -40px rgba(0,0,0,0.9)`; dropdown `0 24px 56px -22px rgba(0,0,0,0.85)`.

### Signature brand detail — the 15° shear
A recurring brand motif: small accent marks and primary CTAs use a **15° left shear** (`transform: skewX(-15deg)`), with inner content counter-sheared (`skewX(15deg)`) so text stays upright. Applied to: the little red "tick" that precedes eyebrow labels, and the primary "Enter portal" button on the welcome screen. Regular sign-in / download buttons are plain rectangles with `4px` radius (shear reserved for hero moments).

---

## Screens / Views

### 1. Login
**Purpose:** Foreign client signs in. First impression — must feel powerful and premium.

**Layout:** Full-height two-column split (flex, wraps on narrow screens).
- **Left (flex 1.15):** brand hero on a dark radial-red gradient (`radial-gradient(120% 95% at 16% 34%, rgba(237,28,36,0.15), transparent 52%), linear-gradient(158deg,#1e1f21,#101010)`). Contains a faint blueprint grid (60px lines at `rgba(255,255,255,0.022)`, radially masked), a large faint crest watermark bottom-right (6% opacity), and a soft breathing red glow (`@keyframes` opacity .4↔.85 over 9s). Content: red-shear eyebrow "Since 1968 · Made in Serbia", H1 headline, subtitle, and a heritage stat row: **60+** Years of craft · **3** Generations · **150** Specialists (38px weight-800 numbers, `+` in brand red, thin dividers between).
- **Right (flex 0.85):** form panel `#191A1C`, left border `rgba(255,255,255,0.07)`, centered, max-width 392px. Red-shear eyebrow "Engine Remanufacturing", H2 "Sign in to your portal", subtitle, Email field, Password field, right-aligned "Forgot password?" link, full-width red **Sign in** button (48px), and a mono "🔒 Encrypted connection" reassurance line.
- **Top bar (absolute):** MR Engines crest logo left (46px tall); language selector right.

**Inputs:** 46px tall, `background:rgba(255,255,255,0.04)`, border `rgba(255,255,255,0.12)`, radius 4px, padding `0 14px`, text 14.5px. Focus: border → `rgba(237,28,36,0.7)`.

### 2. Welcome (first entry)
**Purpose:** Dignified, subtle welcome the first time a client signs in. Never over-the-top.

**Layout:** Full-height centered column, text-align center, dark bg with top radial-red glow + masked grid. Crest logo (74px) → 60×3px red underline → H1 `{{welcomeTitle}}` → subtitle → primary **Enter portal** button (15° sheared, red, arrow icon).

**Animation:** staggered fade-up on mount — logo `.8s`, underline scaleX `.7s @ .25s`, H1 `.9s @ .35s`, subtitle `.9s @ .55s`, button `.9s @ .8s`. Keyframe `mrFadeUp`: opacity 0→1, `translateY(16px)`→0.

### 3. Claims list (main screen)
**Purpose:** Client sees all their engine claims.

**Layout:** App shell = sticky header + centered `max-width:1180px` main.
- **Header (sticky, 13px 28px):** crest logo (34px) + "CLIENT PORTAL" label (left, clickable → home); right: language selector, divider, account chip (avatar "VD" 34px gradient circle + "Van Dijk Transport / NL · Fleet account"), sign-out icon button (36px square, bordered).
- **Page head:** eyebrow "Overview", H1 "Your claims", subtitle, and a search box (44px, mono placeholder) on the right.
- **Cards grid:** `grid-template-columns: repeat(auto-fill, minmax(328px, 1fr))`, gap 18px. Responsive by design (1 col on phone).

**Claim card (`<button>`):** surface `#202123`, border `rgba(255,255,255,0.07)`, radius 6px, padding 22px, column flex gap 18px. Contents top→bottom: row of claim ID (mono) + **status badge**; engine name (19px/600) + "Application · Client"; a two-col mini-spec (Serial / Power, mono values with tiny uppercase labels); hairline divider; footer row "Submitted {date}" + red "View details →".
- **Hover:** border → `rgba(237,28,36,0.5)`, bg → `#25272A`, `translateY(-3px)`. Transition `.15s`.

**Status badge:** pill, radius 3px, padding `5px 10px`, 11.5px/600, icon + label. Colors per status table. Icons: Accepted = check; In progress = clock; Rejected = warning triangle.

### 4. Claim detail (read-only)
**Purpose:** Calm, transparent status. Shows ONLY what the client needs — no internal notes, no fault/blame.

**Layout:** "← Back to claims" link; header row = claim ID (mono red) + engine H1 + "Application · Client · Country", with a large **status pill** on the right; hairline divider.

**Status progress bar (the hero element):** full-width horizontal stepper — see "Status progress bar" below.

Then a two-column region (flex, wraps):
- **Main (flex 2, min 320px):**
  - **Inspection report** card — eyebrow-marked H3 + body paragraph.
  - **Inspection photos** card — grid `repeat(auto-fill, minmax(148px,1fr))`, gap 12px. Each tile 4:3, diagonal hatch placeholder background, mono "INSPECTION PHOTO" top-left, caption bar bottom. *(Replace placeholders with real image thumbnails from the API.)*
- **Sidebar (flex 1, min 268px):**
  - **Engine details** card — Model / Application / Serial number / Power output (label left, value right; serial & power in mono).
  - **Your contact** card — assigned technician avatar (initials) + name + "Assigned technician"; email row (envelope icon) + phone row (phone icon, mono). Icons in brand red.
  - **Download full report** — full-width red button (48px) with download icon.

---

## Status progress bar (detailed spec)
A continuous full-width horizontal stepper with three nodes whose **centers align to the left and right edges** of the content (i.e. the track runs edge-to-edge, matching the width of the Inspection report + Engine details region).

**Structure:**
- Header row: eyebrow "Status" (left) + right-aligned `{pct}% {completeWord}` (percentage in status color, 17px/700 mono; word in `#C9CACC`).
- A relative container. Behind the nodes: a background rail (`left:15px; right:15px; top:13px; height:3px; background:rgba(255,255,255,0.10)`) and an animated **fill** rail on top (`left:15px; top:13px; height:3px`), `width` set per state, `background` = status gradient, `box-shadow` = status glow, `transition: width 1.15s cubic-bezier(.45,.05,.2,1)`.
- Three node columns via `display:flex; justify-content:space-between`, each `flex:1`, with alignment: node 1 `align-items:flex-start`/text-left, node 2 `center`/center, node 3 `flex-end`/text-right. Each column: 30px node circle, then label (14px/600, margin-top 13px), then sub (12px mono `#A3A4A8`).

**Node states (30px circle, border 1.5px):**
- **Done:** bg `#182420`, border `#1FA971`, green check icon `#3DD693`.
- **Current:** bg `#26210F`, border `#F5A623`, pulsing amber dot (`mrGlow` 1.7s), plus a 5px `rgba(245,166,35,0.10)` outer ring.
- **Pending:** bg `#1a1b1d`, border `rgba(255,255,255,0.16)`, hollow grey inner ring.
- **Reject:** bg `#26160F`, border `#D92D20`, red X icon `#F0625B`.

**Per-status configuration** (steps are: Received → In inspection → Decision):
| Status | Steps | Fill width | Fill gradient | Glow | Pct |
|---|---|---|---|---|---|
| In progress | done, **current**, pending | `calc(50% - 15px)` | `linear-gradient(90deg,#C9871B,#F5A623)` | `0 0 12px rgba(245,166,35,0.45)` | 50% |
| Accepted | done, done, **done** | `calc(100% - 30px)` | `linear-gradient(90deg,#158257,#3DD693)` | `0 0 12px rgba(31,169,113,0.5)` | 100% |
| Rejected | done, done, **reject** | `calc(100% - 30px)` | `linear-gradient(90deg,#8F241D,#D9463C)` | `0 0 12px rgba(217,45,32,0.42)` | 100% |

**Fill animation:** on entering the detail screen, the fill width starts at `0px` and, after two `requestAnimationFrame` ticks, transitions to the target width — producing a "growing progress bar" effect (~1.15s). Re-runs each time a claim is opened.

---

## Interactions & Behavior
- **Login → Sign in:** goes to Welcome (unless `showWelcome` is false → straight to Claims). No real auth in the mock.
- **Welcome → Enter portal:** goes to Claims.
- **Claims card click:** opens Claim detail, scrolls to top, triggers the fill animation.
- **Back to claims / logo click:** returns to Claims (scroll to top).
- **Sign out icon:** returns to Login.
- **Language selector:** dropdown (click outside to close) with 6 languages; selecting one re-renders all copy instantly. Selector shown on both Login and the app header.
- **Download full report:** in the mock, generates a `.txt` summary blob and downloads it. In production, wire to the real PDF endpoint.
- **Hover states:** cards lift + red border; buttons darken/lighten red (`#ED1C24`↔`#F0414A`); links `#A3A4A8`→`#F5F5F5`.
- **Transitions:** most `.15s`; progress fill `1.15s`; welcome fades `.7–.9s`.
- **Responsive:** login split wraps to stacked; claims grid collapses to 1 column; detail two-column region wraps. Everything must work on a phone (client requirement). Keep tap targets ≥44px.

## State Management
- `screen`: `'login' | 'welcome' | 'claims' | 'detail'` (route/view).
- `lang`: `'en' | 'sr' | 'es' | 'nl' | 'de' | 'fr'` — persist to localStorage in production; default `en`.
- `langOpen`: boolean, language dropdown open.
- `selected`: currently opened claim id (for the detail view).
- `filled`: boolean driving the progress-fill animation (false→true after mount/open).
- **Data fetching (production):** list of claims for the signed-in account; single claim detail incl. report text, gallery image URLs, engine spec, assigned technician, status, and status history/dates. The API must expose only client-safe fields (no internal notes, no fault attribution).

### Claim data shape (from the mock)
```
{
  id: "MRE-2026-0148",
  engine: "Iveco Cursor 13",
  application: "Freight",
  serial: "CR13-884213",
  power: "420 hp / 309 kW",
  dateLabel: "18 Jun 2026",
  status: "progress" | "accepted" | "rejected",
  country: "Netherlands",
  client: "Van Dijk Transport B.V.",
  report: "<paragraph of client-safe inspection text>",
  gallery: [{ caption, sub }],           // → real image URLs in prod
  tech: { name, email, phone }           // assigned technician / contact
}
```

## Internationalization
All copy is keyed and provided in **6 languages** (EN/SR/ES/NL/DE/FR) — see the `I18N()` map in `MR Engines Portal.dc.html` for the full, ready-to-use translation table (labels, statuses, timeline words, buttons, etc.). Default language is **English** (foreign clients). Move these into the codebase's i18n system (e.g. i18next). Note: technical report bodies are kept in English in the mock — confirm with the client whether reports should be translated.

## Assets
- `assets/mr-crest.png` — the MR Engines heritage crest logo (full lockup: "MR", white "Engines", "MADE IN SERBIA" stamp). Supplied by the client; already cropped tight with transparent background. Use the client's official vector/logo in production if available.
- Icons are inline SVGs (feather-style: check, clock, warning triangle, X, search, mail, phone, download, arrows, chevron, lock). Replace with the codebase's icon library (e.g. lucide-react, which matches this style).
- Inspection photos are **placeholders** (hatched tiles) — wire to real claim photo URLs.
- Fonts: Figtree + JetBrains Mono (Google Fonts).

## Files
- `MR Engines Portal.dc.html` — the full portal prototype (all 4 screens, logic, i18n, animations). Primary reference.
- `Login Concepts.dc.html` — three explored login directions (1a editorial split — the chosen one, 1b centered vault, 1c cinematic bottom bar). Context for the login design decision.
- `assets/mr-crest.png` — logo asset.
- `support.js` — the prototype runtime. **Reference only — do not port.**
